import random,time,json,sys
from pathlib import Path
seed=(Path(__file__).resolve().parent / "replay_257.py").read_text().split("raw='''")[1].split("'''")[0]
base=[(t[0],int(t[1:])) for t in seed.split()]
from bank_cap_probe import compile,canonical,unpaid_local_caps
rng=random.Random(771)
n=257
rest=[('K',k) for k in range(1,n+1)]+[('K',k) for k in range(n-1,0,-1)]
start=time.monotonic(); pool=[list(base)];checked=0;positives=0;blind=0;peak=0;minvis=100
for iteration in range(1500):
 cur=rng.choice(pool if rng.random()<.7 else pool[:1]);raw=cur[:]
 edits=1 if rng.random()<.8 else rng.randrange(2,7)
 for _ in range(edits):
  pos=rng.randrange(len(raw));choice=rng.randrange(8)
  if choice==0:
   m,k=raw[pos];raw[pos]=('D' if m=='K' else 'K',k)
  elif choice==1:
   m,k=raw[pos];raw[pos]=(m,max(1,min(n,k+rng.choice([-1,1])*rng.choice([1,2,4,8,16,32,64]))))
  elif choice==2:
   raw.insert(pos,('K',rng.randint(1,n)))
  elif choice==3:
   raw.insert(pos,('D',rng.randint(1,n)))
  elif choice==4:
   raw[pos:pos]=[('K',rng.randint(1,n)),('K',rng.randint(1,n))]
  elif choice==5:
   del raw[pos:pos+rng.randrange(1,6)]
  elif choice==6:
   raw.insert(pos,raw[pos])
  else:
   m,k=raw[pos];raw[pos]=(m,n+1-k)
 if len(raw)>280:raw=raw[:280]
 try:
  comp=compile(n,raw+rest);bank=canonical(comp)
 except AssertionError as e:
  print('invalid',e);break
 checked+=1;positive=bank['unpaid']>0;positives+=positive
 if positive:
  info=unpaid_local_caps(comp,bank,5)
  visible5=sum(z["visibility_threshold"]<=5 for z in info)
  invisible5=bank['unpaid']-visible5
  if invisible5>0:
   blind+=1;print('FOUND INVI5',iteration,'A',comp['A'],'Q',comp['Q'],'Omega',bank['unpaid'],'invis',invisible5,'info',info[:15],flush=True)
   with open(str(Path(__file__).resolve().parent / 'bank_cap_blind5.json'),'w') as f:json.dump(dict(n=n,raw=raw,A=comp['A'],Q=comp['Q'],Omega=bank['unpaid'],info=info),f)
   break
  if bank['unpaid']>peak:
   peak=bank['unpaid'];print('new omega peak',iteration,'Omega',peak,'A',comp['A'],'Q',comp['Q'],'vis1',sum(z['visibility_threshold']<=1 for z in info),'vis2',sum(z['visibility_threshold']<=2 for z in info),'vis5',visible5,'t',round(time.monotonic()-start,1),flush=True)
  if rng.random()<.9 and len(pool)<40:pool.append(raw)
 elif rng.random()<.01 and len(pool)<30:pool.append(raw)
 if checked%100==0:print('progress',checked,'positive',positives,'peak',peak,'t',round(time.monotonic()-start,1),flush=True)
 if time.monotonic()-start>30:break
print('FINAL',checked,positives,'peak',peak,'blind',blind,'seconds',round(time.monotonic()-start,2))
