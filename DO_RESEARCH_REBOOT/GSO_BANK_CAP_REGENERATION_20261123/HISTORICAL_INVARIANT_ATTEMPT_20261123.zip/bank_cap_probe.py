"""Independent small exact physical probe; no universal proof is inferred."""
from collections import Counter
import random, json

class Tree:
 def __init__(self,n):
  self.n=n; self.l=[0]*(n+1);self.r=[0]*(n+1);self.p=[0]*(n+1);self.root=1
  for i in range(1,n):self.r[i]=i+1;self.p[i+1]=i
 def rot(self,x):
  y=self.p[x]; assert y
  g=self.p[y]; is_right=self.r[y]==x
  mid=(self.l[x] if is_right else self.r[x])
  bit=(x,y,g,mid)
  if is_right:self.r[y]=mid;self.l[x]=y
  else:self.l[y]=mid;self.r[x]=y
  if mid:self.p[mid]=y
  self.p[y]=x;self.p[x]=g
  if g:
   if self.l[g]==y:self.l[g]=x
   else:assert self.r[g]==y;self.r[g]=x
  else:self.root=x
  return bit
 def steps(self,x):
  while self.p[x]:
   y=self.p[x];g=self.p[y]
   if not g:yield ('ZIG',[self.rot(x)])
   else:
    typ=('R' if self.r[g]==y else 'L')+('R' if self.r[y]==x else 'L')
    if typ in ('LL','RR'):yield (typ,[self.rot(y),self.rot(x)])
    else:yield(typ,[self.rot(x),self.rot(x)])
 def flat(self):return self.root, tuple(self.l),tuple(self.r)
 def intervals(self):
  low=[0]*(self.n+1);high=[0]*(self.n+1)
  st=[(self.root,0)];
  while st:
   v,done=st.pop()
   if done:
    low[v]=low[self.l[v]] if self.l[v] else v
    high[v]=high[self.r[v]] if self.r[v] else v
   else:
    st.append((v,1))
    if self.l[v]:st.append((self.l[v],0))
    if self.r[v]:st.append((self.r[v],0))
  return low,high

def voucher_or_step(b,n,mode,op,x,typ,bits,actor):
 owner=lambda v:(v-1)//5
 scope=sorted({owner(v) for bit in bits for v in bit if v})
 order=[owner(x)]+[o for o in scope if o!=owner(x)]
 if actor=='B' and typ in ('LL','RR'):
  a,c=bits; roles=[x,c[3],a[2],a[1],c[1],a[3]]
  order=[]
  for v in roles:
   if v and owner(v) not in order:order.append(owner(v))
 assert set(order)==set(scope),(actor,typ,scope,order)
 return dict(op=op,id=(actor,op),a=(actor=='A'),k=False,q=(actor=='B' and len(bits)==2),
             target=x,scope=scope,order=order,typ=typ)

def compile(n,operations,collect_states=False):
 a=Tree(n);b=Tree(n);events=[];qevents=[];ac=0; qc=0;gk=0
 for op,(mode,x) in enumerate(operations,1):
  if mode=='K' and b.root!=x:
   gk+=1;events.append(dict(op=op,id=('K',op),a=False,k=True,q=False,target=x,
       scope=[(x-1)//5],order=[(x-1)//5],typ='VOUCHER'))
  for typ,bits in a.steps(x):
   ac+=1;events.append(voucher_or_step(b,n,mode,op,x,typ,bits,'A'))
  if mode=='K':
   for typ,bits in b.steps(x):
    eb=voucher_or_step(b,n,mode,op,x,typ,bits,'B')
    # To store B state BEFORE, undo direct generator impossible (steps yielded after rotate).
    # save A and B state after for interval analysis with next B states or recompute later.
    events.append(eb);qc+=int(eb['q'])
  if collect_states:pass
 assert a.flat()==b.flat() and a.flat()==Tree(n).flat(), 'not closed'
 return dict(n=n,ops=operations,events=events,A=ac,Q=qc,gk=gk)

def sweep(events,nb,stock,record=False):
 st=list(stock); paid=unpaid=issued=0;rows=[]
 for e in events:
  order=e['order'];mass=sum(st[v] for v in order)
  if e['a'] or e['k']:
   for v in order:st[v]=5
   ip=sum(st[v] for v in order)-mass;pp=0;up=0
  else:
   pp=min(mass,int(e['q']));up=int(e['q'])-pp;ip=0
   left=mass-pp
   for v in order:st[v]=min(5,left);left-=st[v]
  paid+=pp;unpaid+=up;issued+=ip
  if record:rows.append((e['id'],e['typ'],tuple(order),mass,pp,up))
 assert sum(st)-sum(stock)==issued-paid
 return st,dict(paid=paid,unpaid=unpaid,issued=issued,rows=rows)

def canonical(comp):
 n=comp['n'];b=(n+4)//5; stock=[5]*b
 for i in range(b*5+1):
  new,c=sweep(comp['events'],b,stock)
  assert all(x<=y for x,y in zip(new,stock))
  if new==stock:break
  stock=new
 else:raise Exception('no fixed point')
 final,result=sweep(comp['events'],b,stock,True)
 assert final==stock and result['paid']+result['unpaid']==comp['Q']
 assert result['issued']==result['paid'] and result['issued']<=45*comp['A']
 return result

def visible(n,operations,rows,caps=(1,2,3,4,5,8,16)):
 # second physical replay collects A snapshot after A phase and two before/after B subtrees
 a=Tree(n);b=Tree(n);i=0;vis=Counter();by_id={}; examples=[]
 def psi(aivs,bt,c):
  lb,hb=bt.intervals();ans=0
  for al,ar in aivs:
   if al==1 and ar==n:continue
   cnt=0
   for v in range(al,ar+1):
    if lb[v]<al or hb[v]>ar:
     cnt+=1
     if cnt>=c:break
   ans+=min(c,cnt)
  return ans
 for op,(mode,x) in enumerate(operations,1):
  if mode=='K' and b.root!=x:assert rows[i][0]==('K',op);i+=1
  for typ,bits in a.steps(x):assert rows[i][0]==('A',op);i+=1
  if mode=='K':
   intervals=a.intervals();aivs=list(zip(*intervals))
   # aivs zip includes index0 dummy interval [0,0], don't include
   aivs=aivs[1:]
   for typ,bits in b.steps(x):
    # We need pre-rotation B state: instead get former snap pre-step by separate replay:
    assert rows[i][0]==('B',op);i+=1
  # function has no pre states, replay below
 return vis

def psi(c,n,aiv,bl,bh):
 s=0
 for lo,hi in aiv:
  if lo==1 and hi==n:continue
  cnt=0
  for v in range(lo,hi+1):
   if bl[v]<lo or bh[v]>hi:
    cnt+=1
    if cnt>=c:break
  s+=min(cnt,c)
 return s

def cap_visibility(comp,bank,caps=(1,2,3,5,8,16),only_unpaid=True):
 # replay using manual B splay to obtain pre and post step states
 a=Tree(comp['n']);b=Tree(comp['n']);events=comp['events'];rows=bank['rows'];pos=0
 ret=Counter();info=[]
 for op,(mode,x) in enumerate(comp['ops'],1):
  if mode=='K' and b.root!=x:
   assert rows[pos][0]==('K',op);pos+=1
  for typ,bits in a.steps(x):assert rows[pos][0]==('A',op);pos+=1
  if mode=='D':continue
  low,high=a.intervals();aiv=list(zip(low[1:],high[1:]));
  # manually advance B (generator yields after rotations, so save all psis before)
  while b.p[x]:
   p=b.p[x];g=b.p[p]
   if not g:typ='ZIG';pivs=[x]
   else:
    typ=('R' if b.r[g]==p else 'L')+('R' if b.r[p]==x else 'L')
    pivs=[p,x] if typ in ('RR','LL') else [x,x]
   row=rows[pos];pos+=1;assert row[0]==('B',op) and row[1]==typ
   if only_unpaid and not row[5]:
    for pivot in pivs:b.rot(pivot)
    continue
   bl,bh=b.intervals();old={c:psi(c,comp['n'],aiv,bl,bh) for c in caps}
   for pivot in pivs:b.rot(pivot)
   bl,bh=b.intervals();new={c:psi(c,comp['n'],aiv,bl,bh) for c in caps}
   changes={c:old[c]-new[c] for c in caps}
   assert all(delta>=0 for delta in changes.values()),changes
   ret['unpaid']+=int(row[5]);
   for c in caps:ret[f'visible_{c}']+=int(changes[c]>0)
   info.append((op,typ,changes,row[2],row[3]))
 assert pos==len(events)
 return ret,info

def source_H(p,q):
 n=2**(p+1)*(q+1)+1
 marked={n+1-2**j for j in range(p+1)}
 ops=[('D',k) for k in range(2,n+1)]
 ops +=[('K' if k in marked else 'D',k) for k in range(n,0,-1)]
 ops +=[('K',k) for k in range(1,n+1)]+[('K',k) for k in range(n-1,0,-1)]
 return n,ops

def source_mixed(n,targets,reps=1):
 ops=[('D',k) for k in range(2,n+1)]
 for _ in range(reps):ops+=list(targets)
 ops +=[('K',k) for k in range(1,n+1)]+[('K',k) for k in range(n-1,0,-1)]
 return n,ops

if __name__=='__main__':
 for p,q in [(3,1),(3,3),(3,7),(4,1),(3,15)]:
  n,ops=source_H(p,q);comp=compile(n,ops);b=canonical(comp);ret,info=cap_visibility(comp,b)
  print('H',p,q,'n',n,'A',comp['A'],'Q',comp['Q'],'paid',b['paid'],'unpaid',b['unpaid'],ret,'INFO',info[:12],flush=True)

def unpaid_local_caps(comp,bank,max_cap=5):
 """Exact minimal visibility cap for every unpaid double by individual B rotations."""
 n=comp['n']; a=Tree(n);b=Tree(n);events=comp['events'];rows=bank['rows'];pos=0;detail=[]
 for op,(mode,x) in enumerate(comp['ops'],1):
  if mode=='K' and b.root!=x:
   assert rows[pos][0]==('K',op);pos+=1
  for typ,bits in a.steps(x):assert rows[pos][0]==('A',op);pos+=1
  if mode=='D':continue
  al,ah=a.intervals()
  while b.p[x]:
   p=b.p[x];g=b.p[p]
   if not g:typ='ZIG';pivs=[x]
   else:
    typ=('R' if b.r[g]==p else 'L')+('R' if b.r[p]==x else 'L')
    pivs=[p,x] if typ in ('RR','LL') else [x,x]
   row=rows[pos];pos+=1;assert row[0]==('B',op) and row[1]==typ
   if not row[5]:
    for pivot in pivs:b.rot(pivot)
    continue
   mins=[];info=[]
   for pivot in pivs:
    blo,bhi=b.intervals();bit=b.rot(pivot);oldp=bit[1]
    nlo,nhi=b.intervals();lo=nlo[oldp];hi=nhi[oldp]
    # Find A LCA of interval [lo,hi]
    t=a.root
    while not (lo<=t<=hi):
     t=a.l[t] if t>hi else a.r[t]
     assert t
    candidates=[]
    while t!=a.root:
     aa,bb=al[t],ah[t]
     if aa<=lo and hi<=bb:
      cnt=0
      for v in range(aa,bb+1):
       if blo[v]<aa or bhi[v]>bb:
        cnt+=1
        if cnt>max_cap:break
      candidates.append((t,aa,bb,cnt))
     t=a.p[t]
    m=min((z[3] for z in candidates),default=10**8)
    mins.append(m);info.append((bit,(lo,hi),candidates))
   detail.append(dict(id=('B',op),typ=typ,visibility_threshold=min(mins),per_rotation=mins,geometry=info))
 assert pos==len(events)
 return detail
