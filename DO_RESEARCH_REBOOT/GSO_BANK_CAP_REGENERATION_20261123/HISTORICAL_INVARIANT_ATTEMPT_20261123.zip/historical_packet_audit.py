"""Finite exact audit of historical packet accounting for the attached H5 source engine.

This verifies counts on selected paired-closed sources; the general results
and open bridge are stated/proved mathematically in HISTORICAL_INVARIANT_ATTEMPT.md.
"""
import json
from pathlib import Path
from bank_cap_probe import compile, canonical, source_H
from scan_highcap import scan

ROOT=Path(__file__).resolve().parent

def evaluate(name, n, ops):
    comp=compile(n,ops)
    bank=canonical(comp)
    records=scan(comp,bank,cmax=0)
    P=V=H=M=C=0
    dry_packets=0; dry_max=0; dry_len=0
    first_bad=[];last_op=None;previous_bad=False;previous_good=None
    for idx,r in enumerate(records):
        if r['op']!=last_op:
            last_op=r['op'];previous_bad=False;previous_good=None;dry_len=0
        if r['mass']>0:
            dry_len=0
            P+=1;previous_bad=False;previous_good=idx
        elif r['h']<=5:
            if not dry_len:dry_packets+=1
            dry_len+=1;dry_max=max(dry_max,dry_len)
            V+=1;previous_bad=False;previous_good=idx
        else:
            if not dry_len:dry_packets+=1
            dry_len+=1;dry_max=max(dry_max,dry_len)
            H+=1
            if previous_bad:
                C+=1
            else:
                assert previous_good is not None, 'An invisible unpaid run had no in-access anchor.'
                M+=1;first_bad.append([r['op'],idx,previous_good])
            previous_bad=True
    assert P==bank['paid'] and V+H==bank['unpaid']
    assert H==M+C and M<=P+V and dry_packets<=P and P<=45*comp['A'] and V<=10*comp['A']
    return dict(name=name,n=n,operations=len(ops),A=comp['A'],Q_B=comp['Q'],
                P5=P,visible_unpaid=V,invisible_unpaid=H,
                invisible_packets=M,continuations=C,unpaid_packets=dry_packets,max_unpaid_packet_length=dry_max,Omega5=bank['unpaid'],
                packet_anchor_ids=first_bad)

def original_257():
    src=(ROOT/'replay_257.py').read_text().split("raw='''")[1].split("'''")[0]
    raw=[(t[0],int(t[1:])) for t in src.split()]
    n=257;ops=raw+[('K',k) for k in range(1,n+1)]+[('K',k) for k in range(n-1,0,-1)]
    return evaluate('verified-original-257',n,ops)

if __name__=='__main__':
    out=[original_257()]
    for p,q in [(3,1),(3,3),(3,7),(3,15)]:
        n,ops=source_H(p,q)
        out.append(evaluate('opposite-spine-H-'+str(q),n,ops))
    path=ROOT/'HISTORICAL_PACKET_CHECKS.json'
    path.write_text(json.dumps({'conclusions_are_finite_checks_only':True,'cases':out},indent=2))
    print(json.dumps([ {k:v for k,v in rec.items() if k not in ('packet_anchor_ids',)} for rec in out],indent=2))
