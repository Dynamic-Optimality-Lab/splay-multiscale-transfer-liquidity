from bank_cap_probe import compile,canonical
from scan_highcap import scan
from pathlib import Path
import random,time,json

seed=(Path(__file__).resolve().parent/'replay_257.py').read_text().split("raw='''")[1].split("'''")[0]
base=[(t[0],int(t[1:])) for t in seed.split()]
n=257
rest=[('K',k) for k in range(1,n+1)]+[('K',k) for k in range(n-1,0,-1)]
rng=random.Random(11232026)
pool=[list(base)];scores=[];start=time.monotonic();best=(-1,None);best0=(-1,None); best1=(-1,None);positives=0;tested=0

def mutate(raw):
    raw=raw[:]
    for _ in range(1 if rng.random()<.65 else rng.randint(2,5)):
        pos=rng.randrange(len(raw));a,k=raw[pos]; choice=rng.randrange(9)
        if choice==0:raw[pos]=('D' if a=='K' else 'K',k)
        if choice==1:raw[pos]=(a,min(n,max(1,k+rng.choice([-1,1])*rng.choice([1,2,4,8,16,32,64]))))
        if choice==2:raw.insert(pos,(rng.choice('KD'),rng.randrange(1,n+1)))
        if choice==3:raw.insert(pos,(a,k))
        if choice==4:del raw[pos]
        if choice==5:raw[pos]=(a,n+1-k)
        if choice==6:raw[pos]=(rng.choice('KD'),rng.choice([1,n,62,73,106,110,144,181,226,230,250]))
        if choice==7:raw[pos]=(a,max(1,min(n,k+rng.randint(-12,12))))
        if choice==8:raw[pos]=(a,rng.randint(1,n))
    return raw[:260]

for j in range(240):
    if j%17==0:raw=list(base)
    else:raw=mutate(rng.choice(pool) if rng.random()<.8 else base)
    try:
        comp=compile(n,raw+rest);bank=canonical(comp)
        if not bank['unpaid']:continue
        positives+=1
        rr=scan(comp,bank,2)
        q0=[r for r in rr if r['mass']==0];q1=[r for r in rr if r['mass']==1];q2=[r for r in rr if r['mass']==2]
        h0=max((r['h'] for r in q0),default=-1)
        h1=max((r['h'] for r in q1),default=-1)
        h2=max((r['h'] for r in q2),default=-1)
        if h0>best0[0]:
            best0=(h0,(j,bank['unpaid'],comp['A']))
            print('H0',best0,flush=True)
        if h1>best1[0]:
            best1=(h1,(j,bank['unpaid'],comp['A']))
            print('H1',best1,flush=True)
        score=h0+max(0,h1-3)+max(0,h2-6)
        if score>best[0]:
            best=(score,(j,h0,h1,h2,bank['unpaid'],comp['A']))
            print('NEW-BEST',best,flush=True)
        if h0>5:
            print('BC5-COUNTEREXAMPLE',best0, 'raw',raw,flush=True)
            (Path(__file__).resolve().parent/'bc5_counterexample_candidate.json').write_text(json.dumps({'n':n,'raw':raw,'h0':h0,'A':comp['A'],'Q':comp['Q'],'Omega':bank['unpaid']}))
            break
        if score>=2 and rng.random()<.35:
            pool.append(raw)
            if len(pool)>20:pool.pop(1)
    except AssertionError:
        continue
    tested+=1
    if j%30==0:print('PROGRESS',j,round(time.monotonic()-start,1),'pool',len(pool),'positives',positives,flush=True)
print('FINAL',tested,positives,best,best0,best1,'time',round(time.monotonic()-start,1))
