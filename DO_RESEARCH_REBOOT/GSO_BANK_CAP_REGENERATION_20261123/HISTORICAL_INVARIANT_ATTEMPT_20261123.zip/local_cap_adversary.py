from bank_cap_probe import Tree

def vine_inverted(n):
 a=Tree(n)
 a.l=[0]*(n+1);a.r=[0]*(n+1);a.p=[0]*(n+1);a.root=n
 for i in range(2,n+1):a.l[i]=i-1;a.p[i-1]=i
 return a

def thresholds(n):
 a=vine_inverted(n);b=Tree(n)
 al,ah=a.intervals();x=n;out=[]
 while b.p[x]:
  p=b.p[x];g=b.p[p]
  if not g:pivs=[x];typ='ZIG'
  else:
   typ=('R' if b.r[g]==p else 'L')+('R' if b.r[p]==x else 'L')
   pivs=[p,x] if typ in ('RR','LL') else [x,x]
  minima=[]
  for pv in pivs:
   bl,bh=b.intervals();bit=b.rot(pv); demoted=bit[1];newlo,newhi=b.intervals();lo,hi=newlo[demoted],newhi[demoted]
   rank=[]
   for v in range(1,n+1):
    if v==a.root:continue
    l,r=al[v],ah[v]
    if l<=lo<=hi<=r:
     cnt=sum(bl[u]<l or bh[u]>r for u in range(l,r+1));rank.append(cnt)
   minima.append(min(rank,default=10**9))
  out.append((typ,min(minima),minima))
 return out
for n in [17,33,65,129,257]:
 tab=thresholds(n)
 print('n',n,'first',tab[:2],'6th',tab[5] if len(tab)>5 else None,'last',tab[-3:])
