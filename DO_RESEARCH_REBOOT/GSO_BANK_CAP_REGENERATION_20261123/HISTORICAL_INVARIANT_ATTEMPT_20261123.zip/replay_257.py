from bank_cap_probe import compile,canonical,cap_visibility
raw='''D21 D22 D23 D61 K62 D63 D64 D65 D66 D67 D68 D70 D70 D71 D72 K73 D88 D89 D117 D118 D119 D120 D122 D123 D124 D125 D132 D114 D91 D168 D169 D170 D171 D172 D176 D177 D178 D179 D180 K181 D189 D190 D199 D200 D201 D202 D203 D204 D205 D206 K144 K80 K80 K81 K82 K83 K84 K85 K144 K143 K142 K141 K140 K139 D207 D208 D209 D225 D226 K230 D231 D122 K106 K106 K107 K108 K109 K110 K111 D122 D243 D252 D253 D254 D255 D256 D257 K257 K256 D255 K254 D253 K252 D251 D230 D229 D228 D227 K226 D225 D214 D213 D107 K110 K109 D245 D246 D247 D248 D249 K250 D251 D252 D253 D254 D255 D256 D257 K257 K256 D255 K254 D253 K252 D251 D250 D249 K248 D247 K246 D245 D244 D242 K242 D240 K240 D239 D238 D114 D113 D109 D108 D107 D106 D95 K88 K87 D86 D76 D75 D74 D73 D70 D69 D68 D67 D66 D65 D27 D26 D25 D24 D10 D9 D8 D8 D7 D6 D5 D4 D3 D2 D1'''
raw=[(t[0],int(t[1:])) for t in raw.split()]
print('raw',len(raw));assert len(raw)==173
ops=raw+[('K',k) for k in range(1,258)]+[('K',k) for k in range(256,0,-1)]
comp=compile(257,ops)
b=canonical(comp)
print('Physical', 'ops',len(ops),'A',comp['A'],'Q',comp['Q'],'P',b['paid'],'Omega',b['unpaid']);assert (comp['A'],comp['Q'],b['paid'],b['unpaid'])==(989,519,517,2)
print('Unpaid',[(r[0],r[1],r[2],r[3]) for r in b['rows'] if r[5]])
ret,info=cap_visibility(comp,b,caps=(1,2,3,4,5,6,7,8,10,12,16,20,32,64,128,256))
print('Capped result',ret)
for i in info:print('CAP-UNPAID',i)
