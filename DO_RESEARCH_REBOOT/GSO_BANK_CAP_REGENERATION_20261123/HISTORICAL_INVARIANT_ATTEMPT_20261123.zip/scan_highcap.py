from bank_cap_probe import Tree,compile,canonical,source_H
from collections import Counter
import math,sys

def scan(comp,bank,cmax=40):
    n=comp['n'];a=Tree(n);b=Tree(n);rows=bank['rows'];i=0;records=[]
    for op,(mode,x) in enumerate(comp['ops'],1):
        if mode=='K' and b.root!=x:
            assert rows[i][0]==('K',op);i+=1
        for typ,bits in a.steps(x):
            assert rows[i][0]==('A',op);i+=1
        if mode=='D':continue
        al,ah=a.intervals()
        while b.p[x]:
            p=b.p[x];g=b.p[p]
            if not g:typ='ZIG';pivs=[x]
            else:
                typ=('R' if b.r[g]==p else 'L')+('R' if b.r[p]==x else 'L')
                pivs=[p,x] if typ in ('RR','LL') else [x,x]
            row=rows[i]; i+=1;assert row[0]==('B',op)
            # choose only small stock and q-double (calculate h computationally expensive)
            mass=row[3]; mincap=10**9; per=[]
            if len(pivs)==2 and mass<=cmax:
                for pivot in pivs:
                    blo,bhi=b.intervals();bit=b.rot(pivot)
                    nlo,nhi=b.intervals();lo,hi=nlo[bit[1]],nhi[bit[1]]
                    t=a.root
                    while not lo<=t<=hi:
                        t=a.l[t] if t>hi else a.r[t]
                    minrot=10**9
                    while t!=a.root:
                        left,right=al[t],ah[t]
                        if left<=lo<=hi<=right:
                            cnt=0
                            for v in range(left,right+1):
                                if blo[v]<left or bhi[v]>right:
                                    cnt+=1
                                    if cnt>=minrot:break
                            minrot=min(minrot,cnt)
                        t=a.p[t]
                    per.append(minrot)
                mincap=min(per)
            else:
                for pivot in pivs:b.rot(pivot)
            if len(pivs)==2:records.append(dict(op=op,x=x,mass=mass,h=mincap,typ=typ,per=per,unpaid=row[5]))
    assert i==len(rows)
    return records

if __name__=='__main__':
    from pathlib import Path
    s=Path('replay_257.py').read_text().split("raw='''")[1].split("'''")[0]
    raw=[(t[0],int(t[1:])) for t in s.split()]
    n=257;ops=raw+[('K',k) for k in range(1,n+1)]+[('K',k) for k in range(n-1,0,-1)]
    comp=compile(n,ops);bank=canonical(comp)
    rr=scan(comp,bank)
    high=[r for r in rr if r['h']>5 and r['h']<10**9];small=[r for r in rr if r['mass']<=5]
    print('ALL',len(rr),'highh',len(high),'stock<=5',len(small),'h>5 among small',len([r for r in small if r['h']>5 and r['h']<10**9]))
    print('High cap low stock',sorted(high,key=lambda z:z['mass'])[:30])
    print('Low stock',small[:30])
